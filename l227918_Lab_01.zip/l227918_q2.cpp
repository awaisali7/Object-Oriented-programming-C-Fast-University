
#include <iostream>
using namespace std;

int main ()

{
	int num1, num2;
	
	cout << "Please enter the first number you want to use : ";
	cin >> num1;
	cout << "Please enter the first number you want to use : ";
	cin >> num2;
	
	int* num_ptr_one = &num1;
	int* num_ptr_two = &num2;
	
	
	int sum = *(num_ptr_one) + *(num_ptr_two);
	
	int diff = *(num_ptr_one) - *(num_ptr_two);
	
	int prod  =*(num_ptr_one) * *(num_ptr_two);
	
	int square_one = *(num_ptr_one) * *(num_ptr_one);
	
	int square_two = *(num_ptr_two) * *(num_ptr_two);
	
	cout << "The sum of nums is : " << sum << endl;
	cout << "The difference of nums is : " << diff << endl;
	cout << "The product of nums is : " << prod << endl;
	cout << "The square of first num is : " << square_one << endl;
	cout << "The square of second num is : " << square_two << endl;
	
	
	
	
}
