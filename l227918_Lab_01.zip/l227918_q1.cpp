//
//#include <iostream>
//using namespace std;
//
//int main ()
//
//{
//	
//	int a=1, b=3, c=5;
//
//	int * p;
//
//	int * q;
//
//	int * r;
//
//	p=& a;
//
//	q=& b;
//
//	r=& c;
//
//	cout << a << '\t' << p << '\t' << *p << '\t' << &p << '\t' << &a << endl;
//
//	cout << b << '\t' << q << '\t' << *q << '\t' << &q << '\t' << &b << endl;
//
//	cout << c << '\t' << r << '\t' << *r << '\t' << &r << '\t'<< &c << endl;
//	
//	/*
//	Output
//	1       0x6ffe0c        1       0x6ffdf8        0x6ffe0c
//	3       0x6ffe08        3       0x6ffdf0        0x6ffe08
//	5       0x6ffe04        5       0x6ffde8        0x6ffe04
//	*/
//	
//	
//	
//	return 0;
//}
